filename = 'ex_file/1.txt'


with open(filename) as file_object:
    lines = file_object.readlines()

pistring = ''
for line in lines:
    pistring += line.strip()

print(pistring)