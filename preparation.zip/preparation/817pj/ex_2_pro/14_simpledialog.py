from tkinter.simpledialog import *
from tkinter import *

def xz():
    s=askstring('请输入','请输入一串文字') #askint/askfloat
    lb.config(text=s)

root = Tk()

lb = Label(root,text='')
lb.pack()
btn=Button(root,text='弹出输入对话框',command=xz)
btn.pack()
root.mainloop()
