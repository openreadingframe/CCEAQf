import tkinter as tk

root = tk.Tk()


#增加背景图片
photo = tk.PhotoImage(file="./817pj/ex_1_basic/pic.gif")
theLabel = tk.Label(root,
    text="我是内容,\n请你阅读", #内容
    justify=tk.LEFT,#对齐方式
    image=photo,#加入图片
    compound = tk.CENTER,#关键:设置为背景图片
    font=("仿宋",20),#字体和字号
    fg = "white")#前景色
theLabel.pack()

 

tk.mainloop()
