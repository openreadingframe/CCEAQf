from tkinter import *
from PIL import Image, ImageTk

root = Tk()

image = Image.open("zjq.jpg")
photo = ImageTk.PhotoImage(image)

#在Label中显示图片
label = Label(root,image = photo)
label.pack()

root.mainloop()