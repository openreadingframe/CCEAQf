import tkinter as tk
import tkinter.messagebox
#from tkinter import ttk 

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.define function
def hit_me():
    tkinter.messagebox.showinfo(title='Hi', message='你好!')
    tkinter.messagebox.showwarning(title='Hi', message='有警告!')
    tkinter.messagebox.showerror(title='Hi', message='出错了!')
    print(tkinter.messagebox.askquestion(title='Hi', message='你好!')) #return 'yes'/'no'
    print(tkinter.messagebox.askyesno(title='Hi', message='你好!')) #return 'True'/'False'
    print(tkinter.messagebox.askokcancel(title='Hi', message='你好!')) #return 'True'/'False'

#5.set a button
tk.Button(window, text='hit me', bg='green', 
font=('Arial', 14), command=hit_me).pack()

#6.loop
window.mainloop()
