import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set & place entry 
e = tk.Entry(window, show = None) # 明文
e.pack()

#5.define two functions
def insert_point():
    var = e.get()
    t.insert('insert', var)
def insert_end():
    var = e.get()
    t.insert('end', var)

#6.set 2 buttons
b1 = tk.Button(window, text='insert point', width=10, 
                height=2, command=insert_point)
b2 = tk.Button(window, text='insert end', width=10, 
                height=2, command=insert_end)
b1.pack()
b2.pack()

#7.set & place Text(多行文本)
t = tk.Text(window, height=3)
t.pack()

#8.loop
window.mainloop()
