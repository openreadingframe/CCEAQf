import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set & place labels
var = tk.StringVar() #receive the info of hit_me
l = tk.Label(window, textvariable=var,
 bg='green', font=('Arial', 12), width=30, height=2)

l.pack()

on_hit = False
def hit_me():
    global on_hit
    if on_hit == False:
        on_hit = True
        var.set('you hit me')
    else:
        on_hit = False
        var.set('')
    
#5.place the button
b = tk.Button(window, text='hit me', font=('Arial', 12), 
width=10, height=1, command=hit_me)
b.pack()

#6.loop
window.mainloop()
