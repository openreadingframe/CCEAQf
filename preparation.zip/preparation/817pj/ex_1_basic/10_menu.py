import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set a label
l = tk.Label(window, text='    ', bg='green')
l.pack()

#5.define function of menu
counter = 0
def do_job():
    global counter
    l.config(text='do' + str(counter))
    counter += 1

#6.set a menubar
menubar = tk.Menu(window)

#7.set a file menu

#1)define
filemenu = tk.Menu(menubar, tearoff=0)
#2)place it
menubar.add_cascade(label='File', menu=filemenu)
#3)add command
filemenu.add_command(label='New', command=do_job)
filemenu.add_command(label='Open', command=do_job)
filemenu.add_command(label='Save', command=do_job)
filemenu.add_separator() #添加一条分隔线
filemenu.add_command(label='Exit', command=window.quit)

#8.set a edit menu
editmenu = tk.Menu(menubar, tearoff=1)
#place it
menubar.add_cascade(label='Edit', menu=editmenu)

editmenu.add_command(label='Cut', command=do_job)
editmenu.add_command(label='Copy', command=do_job)
editmenu.add_command(label='Paste', command=do_job)

#9.set secondary menu
submenu = tk.Menu(filemenu)
filemenu.add_cascade(label='Import', menu=submenu, underline=0)
submenu.add_command(label='Submenu_1', command=do_job)

#display
window.config(menu=menubar)

#.loop
window.mainloop()
