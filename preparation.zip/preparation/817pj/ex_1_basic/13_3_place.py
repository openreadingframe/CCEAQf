import tkinter as tk
import tkinter.messagebox

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.place

tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='nw')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='n')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='ne')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='w')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='center')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='e')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='sw')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='s')
tk.Label(window, text='top', font=('Arial', 14)).place(x=50, y=100, anchor='se')






#5.loop
window.mainloop()
