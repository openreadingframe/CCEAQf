import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set labels
l = tk.Label(window, text='你好! this is Tkinter',
 bg='green', font=('Arial', 12), width=30, height=2)

#5.place labels
l.pack()
#two methods: l.pack() & l.place()

#6.loop
window.mainloop()
