import tkinter as tk


#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set a canva
#canvas = tk.Canvas(window, bg='green', height=200, width=500)
canvas = tk.Canvas(window, bg='green', height=200, width=500)
image_file = tk.PhotoImage(file='./817pj/ex_1_basic/pic.gif')
image = canvas.create_image(250, 0, anchor='n', image=image_file)

x0, y0, x1, y1 = 100, 100, 150, 150
line = canvas.create_line(x0-50, y0-50, x1-50, y1-50)
oval = canvas.create_oval(x0+120, y0+50, x1+120, y1+50, fill='yellow')
arc = canvas.create_arc(x0, y0+50, x1, y1+50, start=0, extent=180)
rect = canvas.create_rectangle(330, 30, 330+20, 30+20)

canvas.pack(side='top', expand='yes', anchor='w', fill='x')
#5.define function
def moveit():
    canvas.move(oval, 2, 2)

#6.set a button
b = tk.Button(window, text='move item', command=moveit)
b.pack()

#7.loop
window.mainloop()
