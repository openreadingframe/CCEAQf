import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set & place entry (单行文本)
e1 = tk.Entry(window, show='*', font=('Arial', 14))  # 显示成密文
e2 = tk.Entry(window, show=None, font=('Arial', 14)) # 显示成明文
e1.pack()
e2.pack()

#5.loop
window.mainloop()
