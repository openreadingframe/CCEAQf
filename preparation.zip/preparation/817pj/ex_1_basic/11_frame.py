import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set a label
l = tk.Label(window, text='on the window', bg='red',
 font=('Arial', 16))
l.pack()


#5.set a frame
frame = tk.Frame(window)
frame.pack()

#6.set a second frame
#1)set
frame_l = tk.Frame(frame)
frame_r = tk.Frame(frame)
#2)place
frame_l.pack(side='left')
frame_r.pack(side='right')

#7.set six labels
tk.Label(frame_l, text='on the frame_l1', bg='green').pack()
tk.Label(frame_l, text='on the frame_l2', bg='green').pack()
tk.Label(frame_l, text='on the frame_l3', bg='green').pack()
tk.Label(frame_r, text='on the frame_r1', bg='yellow').pack()
tk.Label(frame_r, text='on the frame_r2', bg='yellow').pack()
tk.Label(frame_r, text='on the frame_r3', bg='yellow').pack()

#8.loop
window.mainloop()
