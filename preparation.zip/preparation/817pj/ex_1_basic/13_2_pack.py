import tkinter as tk
import tkinter.messagebox

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.pack
tk.Label(window, text='top', fg='red').pack(side='top')
tk.Label(window, text='bottom', fg='red').pack(side='bottom')
tk.Label(window, text='left', fg='red').pack(side='left')
tk.Label(window, text='right', fg='red').pack(side='right')



#5.loop
window.mainloop()
