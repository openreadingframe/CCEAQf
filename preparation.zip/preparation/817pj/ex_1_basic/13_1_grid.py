import tkinter as tk
import tkinter.messagebox

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.grid
# 以上的代码就是创建一个三行三列的表格，其实 grid 就是用表格的形式定位的。
# 这里的参数 row 为行，colum 为列，padx 就是单元格左右间距，pady 就是单
# 元格上下间距，ipadx是单元格内部元素与单元格的左右间距，ipady是单元格内
# 部元素与单元格的上下间距。

for i in range(3):
    for j in range(3):
        tk.Label(window, text=1).grid(row=i, column=j, padx=10, pady=10, ipadx=10, ipady=10)
        

for i in range(3):
    for j in range(3):
        break
        #tk.Label(window, text=2).grid(row=i, column=j, padx=1, pady=1, ipadx=1, ipady=1)

#5.loop
window.mainloop()
