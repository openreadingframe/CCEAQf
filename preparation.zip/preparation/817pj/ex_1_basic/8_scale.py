import tkinter as tk
from tkinter import ttk 

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set a label
l = tk.Label(window, bg='green', fg='white', width=20, text='empty')
l.pack()

#5.define function
def print_selection(v):
    l.config(text='you have selected' + v)

#6.set a scale
s = tk.Scale(window, label='try me', from_=0, to=10, 
orient=tk.HORIZONTAL, length=200, showvalue=0, tickinterval=1,
resolution=0.1, command=print_selection)
s.pack()

#7.loop
window.mainloop()
