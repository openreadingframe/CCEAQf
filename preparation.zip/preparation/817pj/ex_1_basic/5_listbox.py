import tkinter as tk

#1.实例化object,建立窗口
window = tk.Tk()

#2.name
window.title('My Window')

#3.set length & width
window.geometry('500x300')

#4.set a label
var1 = tk.StringVar()

l = tk.Label(window, bg='green', fg='yellow', font=("Arial", 12),
width=10, textvariable=var1)
l.pack()

#5.set a function
def print_selection():
    value = lb.get(lb.curselection())
    var1.set(value)

#6.set a button
b1 = tk.Button(window, text='print selection', width=15, 
height=2, command=print_selection)
b1.pack()

#7.set a listbox
var2 = tk.StringVar()
var2.set((1,2,3,4))

lb = tk.Listbox(window, listvariable=var2)

list_items = [11, 22, 33, 44]
for item in list_items:
    lb.insert('end', item) #从最后一个位置开始加入值

lb.insert(1, 'first')
lb.insert(2, 'second')
lb.delete(2)
lb.pack()

#8.loop
window.mainloop()
